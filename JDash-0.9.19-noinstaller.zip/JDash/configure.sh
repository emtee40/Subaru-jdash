java -jar JDashConfig.jar
